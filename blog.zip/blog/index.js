import express from "express";
import mongoose from "mongoose";
import { userRouter } from "./controller/users.controller.js";
import { postRouter } from "./controller/post.controller.js";
import { likeRouter } from "./controller/favourite.controller.js";
import dotenv from "dotenv";

//.ENV
dotenv.config();

const app = express();

app.use(express.json());

//Route
app.use("/users", userRouter);
app.use("/posts", postRouter);
app.use("/favourites", likeRouter);

mongoose
  .connect(process.env.MONGODB)
  .then(() =>
    app.listen(process.env.ROUTER, () => console.log("app run time "))
  )
  .catch((error) => {
    console.error("error connecting to mongodb", error);
  });
