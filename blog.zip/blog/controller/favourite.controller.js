import express from "express";
import { favouriteModel } from "../model/favourite.model.js";
import { postModel } from "../model/post.model.js";

const likeRouter = express.Router();


// api thich bai viet 
likeRouter.post("/like/:postId", async (req, res) => {
  try {
    const postId = req.params.postId;
    if (!postId) throw new Error("not available ID");
    const post = await postModel.findById(postId);
    if (!post) throw new Error("not available post");
    const newPost = await favouriteModel.create({
      userId: post.userId,
      author: post.author,
      title: post.title,
      content: post.content,
      like: "<3",
    });

    res.status(201).send({
      data: newPost,
      messgae: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { likeRouter };
