import express from "express";
import { userModel } from "../model/users.model.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { authen } from "../middleware/authen.js";

const userRouter = express.Router();

//API dang ky
userRouter.post("/register", async (req, res) => {
  try {
    const { username, email, password, role } = req.body;

    //validay
    // if (!username) throw new Error("not available username");
    // if (!email) throw new Error("not available email");
    // if (!password) throw new Error("not available password");
    // if (!role) throw new Error("not available role");

    // hassing passwrod
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    //model
    const user = await userModel.create({
      username,
      email,
      password: hashedPassword,
      role,
    });

    res.status(201).send({
      data: user,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// API dang nhap

userRouter.post("/login", async (req, res) => {
  try {
    // lay du lieu tu body
    const { username, email, password } = req.body;
    //validay
    if (!username && !email) throw new Error("not email or username");
    if (!password) throw new Error("not available passowrd");
    // tim password qua email or username
    const user = await userModel.findOne({
      username: req.body.username || { $ne: null },
      email: req.body.email || { $ne: null },
    });
    if (!user) throw new Error("not available user");
    // lay ra password
    const result = await bcrypt.compare(password, user.password); // ( ham so sanh mat khau )
    // ktra pasword
    if (!result) throw new Error("password false");

    // encode token ( mã hóa )  ( Access token + refresh token )
    const payload = {
      id: user._id.toString(),
      username: user.username,
      email: user.email,
      role: user.role,
    };

    // ký thêm key
    var accessToken = jwt.sign(payload, process.env.JWT_ACCESS_TOKEN, {
      expiresIn: "30m",
    });

    var refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_TOKEN, {
      expiresIn: "1d",
    });

    res.status(200).send({ accessToken, refreshToken });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

userRouter.get("/all", authen, async (req, res) => {
  const user = await userModel.find({});
  res.status(200).send(user);
});

// chinh sua thong tin ca nhan ...

userRouter.put("/update/:putId", authen, async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    const putId = req.params.putId;

    // Kiểm tra xác thực
    // code toan loi@

    // Hassing password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Cập nhật thông tin người dùng
    const updatedUser = await userModel.findByIdAndUpdate(
      putId,
      {
        username,
        email,
        password: hashedPassword,
        role,
      },
      { new: true }
    );

    res.status(201).send({
      data: updatedUser,
      message: "Cập nhật thông tin người dùng thành công",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { userRouter };
