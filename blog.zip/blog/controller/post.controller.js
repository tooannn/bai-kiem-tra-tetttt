import express from "express";
import { postModel } from "../model/post.model.js";
import { authen } from "../middleware/authen.js";
import { userModel } from "../model/users.model.js";

const postRouter = express.Router();

// API tao bai viet
postRouter.post("/register/:postId", authen, async (req, res) => {
  try {
    const postId = req.params.postId;
    const { title, content } = req.body;

    //validay ( k can boi vi co required = true)
    if (!postId) throw new Error("not available postId");

    // if (!title) throw new Error("not available title");
    // if (!content) throw new Error("not available content");
    const user = await userModel.findById(postId);
    // check 1 tac gia 1 bai viet
    const existingPost = await postModel.findOne({
      author: user.username,
      title,
    });

    if (existingPost) throw new Error("avalable title ");

    // create
    const post = await postModel.create({
      userId: postId,
      author: user.username,
      title,
      content,
    });

    res.status(201).send({
      data: post,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// update post

postRouter.put("/update/:putId", authen, async (req, res) => {
  try {
    const { title, content } = req.body;
    const putId = req.params.putId;
    //validay
    if (!putId) throw new Error("not available putId");

    // Kiểm tra xem người dùng hiện tại có quyền chỉnh sửa bài viết không
    const currentUser = req.user;
    const postToEdit = await postModel.findById(putId);

    if (!postToEdit) {
      throw new Error("Bài viết không tồn tại");
    }

    if (postToEdit.author !== currentUser.username) {
      throw new Error("Bạn không có quyền chỉnh sửa bài viết này");
    }

    const post = await postModel.findByIdAndUpdate(
      putId,
      { title, content },
      { new: true }
    );

    res.status(201).send({
      data: post,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// danh sach tac gia

postRouter.get("/author", async (req, res) => {
  try {
    const post = await postModel.find({});

    const newPost = post.map((value) => value.author);

    res.status(200).send(newPost);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// API detail 1 bai viet theo id
postRouter.get("/:getId", async (req, res) => {
  try {
    const getId = req.params.getId;
    if (!getId) throw new Error("not available Id");
    const post = await postModel.findById(getId);
    if (!post) throw new Error("not avalable post");
    res.status(200).send({
      data: post,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// API detail tac gia theo id

postRouter.get("/author/:getId", async (req, res) => {
  try {
    const getId = req.params.getId;
    if (!getId) throw new Error("not available Id");
    const post = await postModel.findById(getId);
    console.log("post:>>", post);
    if (!post) throw new Error("not available psots ");
    const user = await userModel.findById(post.userId).select("-password");
    console.log("idd : >>", user);
    if (!user) throw new Error("not available user");
    res.status(200).send({
      data: user,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { postRouter };
