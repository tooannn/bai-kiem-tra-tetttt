import mongoose from "mongoose";

const Schema = mongoose.Schema;
const favouriteSchema = new Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true },
  author: { type: String, required: true },
  title: { type: String, required: true },
  content: { type: String, required: true },
  like: { type: String, required: true },
});

const favouriteModel = mongoose.model("favourite", favouriteSchema);

export { favouriteModel };
